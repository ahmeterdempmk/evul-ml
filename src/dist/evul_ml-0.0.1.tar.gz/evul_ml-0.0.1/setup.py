from setuptools import setup, find_packages

setup(
    name = "evul-ml",
    version = "0.0.1",
    author = "Ahmet Erdem Pamuk",
    author_email = "ahmeterdempmkk@gmail.com",
    description = "With evul-ml, you can find the best regression or classification models easily in your machine learning projects.",
    url = "https://github.com/ahmeterdempmk/evul-ml",
    packages = find_packages(),
    install_requires = ["sklearn",
                         "numpy", 
                         "pandas", 
                         "xgboost"],
    license = "Apache License 2.0"
)