
## evul-ml

- evul-ml is sklearn based a model selection library for machine learning workings.